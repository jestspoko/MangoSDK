//
//  MangoSDK.h
//  MangoSDK
//
//  Created by Lukasz Czechowicz on 17.01.2017.
//  Copyright © 2017 FriendlyScore. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MangoSDK.
FOUNDATION_EXPORT double MangoSDKVersionNumber;

//! Project version string for MangoSDK.
FOUNDATION_EXPORT const unsigned char MangoSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MangoSDK/PublicHeader.h>


